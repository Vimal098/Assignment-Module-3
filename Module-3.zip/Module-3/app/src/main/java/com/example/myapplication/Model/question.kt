package com.example.myapplication.Model

data class question(
    var id : Int,
    var que : String
)
