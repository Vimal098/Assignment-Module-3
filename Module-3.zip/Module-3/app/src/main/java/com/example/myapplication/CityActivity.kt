package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication.databinding.ActivityCityBinding

class CityActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCityBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSurat.setOnClickListener {
            var intent = Intent(this,FragmentActivity::class.java)
            startActivity(intent)
        }
    }
}