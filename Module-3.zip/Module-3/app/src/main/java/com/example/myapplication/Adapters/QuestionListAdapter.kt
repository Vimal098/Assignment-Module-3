package com.example.myapplication.Adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Adapter
import com.example.myapplication.ActivityLifeCycle
import com.example.myapplication.BackgroundColorActivity
import com.example.myapplication.CityActivity
import com.example.myapplication.DataPassActivity
import com.example.myapplication.FragmentActivity
import com.example.myapplication.FragmentAndFragmentLifeCycle
import com.example.myapplication.HelloWorldActivity
import com.example.myapplication.Model.question
import com.example.myapplication.RJavaFileActivity
import com.example.myapplication.SignUpActivity
import com.example.myapplication.databinding.QuestionListBinding

class QuestionListAdapter(var context: Context,var quesList: MutableList<question>):
RecyclerView.Adapter<QuestionListAdapter.MyViewHolder>(){
    class MyViewHolder(val binding: QuestionListBinding):RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup,viewType: Int):QuestionListAdapter.MyViewHolder {

        var binding= QuestionListBinding.inflate(LayoutInflater.from(context),parent,false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: QuestionListAdapter.MyViewHolder, position: Int) {
        var Quest = quesList[position]
        holder.binding.tvQuest.text= "${Quest.que}"
        holder.binding.cardView.setOnClickListener {
            when(Quest.id){
                1->{
                    val intent = Intent(context,HelloWorldActivity::class.java)
                     context.startActivity(intent)
                }
                2->{
                    val intent = Intent(context,BackgroundColorActivity::class.java)
                    context.startActivity(intent)
                }
                6->{
                    val intent = Intent(context,RJavaFileActivity::class.java)
                    context.startActivity(intent)
                }
                7->{
                    val intent = Intent(context,ActivityLifeCycle::class.java)
                    context.startActivity(intent)
                }
                8->{
                    val intent = Intent(context,FragmentAndFragmentLifeCycle::class.java)
                    context.startActivity(intent)
                }
                5->{
                    val intent = Intent(context,SignUpActivity::class.java)
                    context.startActivity(intent)
                }
                3->{
                    val intent = Intent(context,DataPassActivity::class.java)
                    context.startActivity(intent)
                }
                4->{
                    val intent = Intent(context,DataPassActivity::class.java)
                    context.startActivity(intent)
                }
                9->{
                    val intent = Intent(context,CityActivity::class.java)
                    context.startActivity(intent)
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return quesList.size
    }
}