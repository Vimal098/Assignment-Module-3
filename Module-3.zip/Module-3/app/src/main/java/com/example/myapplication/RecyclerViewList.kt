package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.Adapters.QuestionListAdapter
import com.example.myapplication.Model.question
import com.example.myapplication.databinding.ActivityMainBinding

class RecyclerViewList : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    private var questionList = mutableListOf<question>()
    private lateinit var questionAdapter: QuestionListAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prepareData()
        questionAdapter = QuestionListAdapter(this,questionList)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = questionAdapter
    }

    private fun prepareData() {
        questionList.add(question(1,"1.Create “hello world” application "))
        questionList.add(question(2,"2.Change screen background color on different button click event"))
        questionList.add(question(3,"3.Navigate between one screen to another screen "))
        questionList.add(question(4,"4.Pass data from one screen to second screen "))
        questionList.add(question(5,"5.Design login and registration screen  "))
        questionList.add(question(6,"6.What is R.java file "))
        questionList.add(question(7,"7.What is activity and activity lifecycle "))
        questionList.add(question(8,"8.What is fragment and fragment lifecycle "))
        questionList.add(question(9,"9.Activity to fragment and fragment to activity "))
    }
}