package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class ShowDataActivity : AppCompatActivity() {
    val tvdetail : TextView
        get() = findViewById(R.id.tv_detail)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_data)

        var detail = intent.getStringExtra("Detail")
        if (detail!=null){
            tvdetail.text = "$detail"
        }
    }
}