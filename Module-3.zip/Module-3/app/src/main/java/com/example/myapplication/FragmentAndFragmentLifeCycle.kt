package com.example.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class FragmentAndFragmentLifeCycle : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fragment_and_fragment_life_cycle)
    }
}