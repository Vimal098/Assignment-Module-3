package com.example.myapplication

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import com.example.myapplication.databinding.ActivityBackgroundColorBinding
import com.example.myapplication.databinding.ActivityMainBinding

class BackgroundColorActivity : AppCompatActivity() {
    private lateinit var binding: ActivityBackgroundColorBinding
    @SuppressLint("ResourceAsColor")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityBackgroundColorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.relative
        binding.btnCool.setOnClickListener {
            binding.relative.setBackgroundColor(R.color.cool)
        }
        binding.btnWarm.setOnClickListener {
            binding.relative.setBackgroundColor(R.color.warm)
        }
    }
}