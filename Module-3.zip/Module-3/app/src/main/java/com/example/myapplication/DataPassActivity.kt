package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class DataPassActivity : AppCompatActivity() {
    lateinit var btnNext : Button
    val etdetail : EditText
        get() = findViewById(R.id.et_detail)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_pass)

        btnNext = findViewById(R.id.btn_next)
        btnNext.setOnClickListener {
            var detail = etdetail.text.toString().trim()

            var intent = Intent(this,ShowDataActivity::class.java)
            intent.putExtra("Detail",detail)
            startActivity(intent)
        }
    }
}